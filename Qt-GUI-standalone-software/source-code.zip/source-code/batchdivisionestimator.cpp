#include "batchdivisionestimator.h"

#include "geometryio.h"
#include "neighborpair.h"
#include "polygonitem.h"
#include "weightedmatching.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QGraphicsItem>
#include <QGraphicsScene>
#include <QHash>
#include <QImage>
#include <QPainter>
#include <QRegularExpression>
#include <QSet>
#include <QTextStream>

#include <algorithm>
#include <cmath>
#include <memory>
#include <utility>

namespace {
bool isRealDivisionHeader(const QString &line)
{
    const QStringList fields = line.toLower().split(QRegularExpression("[,;\\s]+"),
                                                    Qt::SkipEmptyParts);
    const QString joinedFields = fields.join(QStringLiteral("_"));
    if (joinedFields == QStringLiteral("real_division_pair")
            || joinedFields == QStringLiteral("realdivisionpair")) {
        return true;
    }

    return fields.contains(QStringLiteral("first_cell_index"))
            && fields.contains(QStringLiteral("second_cell_index"));
}

QVector<PolygonItem*> collectPolygons(QGraphicsScene *scene)
{
    QVector<PolygonItem*> polygons;
    if (!scene)
        return polygons;

    polygons.reserve(scene->items().size());
    for (QGraphicsItem *item : scene->items()) {
        if (item && item->type() == PolygonItem::Type)
            polygons.append(static_cast<PolygonItem*>(item));
    }
    return polygons;
}

QHash<int, PolygonItem*> polygonMap(const QVector<PolygonItem*> &polygons)
{
    QHash<int, PolygonItem*> map;
    for (PolygonItem *poly : polygons) {
        if (poly)
            map.insert(poly->id(), poly);
    }
    return map;
}

QVector<QPair<int, int>> computeNeighborPairs(const QVector<PolygonItem*> &polygons)
{
    QVector<QPair<int, int>> pairs;
    for (int i = 0; i < polygons.size(); ++i) {
        for (int j = i + 1; j < polygons.size(); ++j) {
            NeighborPair pair(polygons[i], polygons[j]);
            if (pair.isNeighbor())
                pairs.append(QPair<int, int>(polygons[i]->id(), polygons[j]->id()));
        }
    }
    return pairs;
}

QStringList buildHeaders(const NeighborPairGeometrySettings &settings)
{
    QStringList headers = {
        "fileName",
        "pairIndex",
        "firstPolygonId",
        "secondPolygonId",
        "observed_division",
        "division_timing",
        "exception_label"
    };

    if (settings.computeAreaRatio)
        headers << "areaRatio";
    if (settings.computeAreaStats)
        headers << "areaMean" << "areaMin" << "areaMax" << "areaDiff";

    if (settings.computePerimeterRatio)
        headers << "perimeterRatio";
    if (settings.computePerimeterStats)
        headers << "perimeterMean" << "perimeterMin" << "perimeterMax" << "perimeterDiff";

    if (settings.computeAspectRatio)
        headers << "aspectRatio";
    if (settings.computeAspectRatioStats)
        headers << "aspectMean" << "aspectMin" << "aspectMax" << "aspectDiff";

    if (settings.computeCircularityRatio)
        headers << "circularityRatio";
    if (settings.computeCircularityStats)
        headers << "circularityMean" << "circularityMin" << "circularityMax" << "circularityDiff";

    if (settings.computeSolidityRatio)
        headers << "solidityRatio";
    if (settings.computeSolidityStats)
        headers << "solidityMean" << "solidityMin" << "solidityMax" << "solidityDiff";

    if (settings.computeVertexCountRatio)
        headers << "vertexCountRatio";
    if (settings.computeVertexCountStats)
        headers << "vertexCountMean" << "vertexCountMin" << "vertexCountMax" << "vertexCountDiff";

    if (settings.computeCentroidDistance)
        headers << "centroidDistance" << "centroidDistanceNormalized";

    if (settings.computeUnionAspectRatio)
        headers << "unionAspectRatio";
    if (settings.computeUnionCircularity)
        headers << "unionCircularity";
    if (settings.computeUnionConvexDeficiency)
        headers << "unionConvexDeficiency";

    if (settings.computeNormalizedSharedEdgeLength)
        headers << "normalizedSharedEdgeLength" << "sharedEdgeLength";

    if (settings.computeSharedEdgeUnsharedVerticesDistance)
        headers << "sharedEdgeUnsharedVerticesDistance";
    if (settings.computeSharedEdgeUnsharedVerticesDistanceNormalized)
        headers << "sharedEdgeUnsharedVerticesDistanceNormalized";

    if (settings.computeCentroidSharedEdgeDistance)
        headers << "centroidSharedEdgeDistance";
    if (settings.computeCentroidSharedEdgeDistanceNormalized)
        headers << "centroidSharedEdgeDistanceNormalized";

    if (settings.computeSharedEdgeUnionCentroidDistance)
        headers << "sharedEdgeUnionCentroidDistance";
    if (settings.computeSharedEdgeUnionCentroidDistanceNormalized)
        headers << "sharedEdgeUnionCentroidDistanceNormalized";
    if (settings.computeSharedEdgeUnionAxisAngle)
        headers << "sharedEdgeUnionAxisAngleDegrees";

    if (settings.computeJunctionAngleAverage)
        headers << "junctionAngleAverageDegrees";
    if (settings.computeJunctionAngleMax)
        headers << "junctionAngleMaxDegrees";
    if (settings.computeJunctionAngleMin)
        headers << "junctionAngleMinDegrees";
    if (settings.computeJunctionAngleDifference)
        headers << "junctionAngleDifferenceDegrees";
    if (settings.computeJunctionAngleRatio)
        headers << "junctionAngleRatio";

    return headers;
}

QString formatValue(double value)
{
    if (!std::isfinite(value))
        return QStringLiteral("N/A");
    return QString::number(value, 'f', 6);
}


QVector<BatchDivisionEstimator::GeometryEntry> sortedNormalizedGeometryEntries(const QVector<BatchDivisionEstimator::GeometryEntry> &entries)
{
    QVector<BatchDivisionEstimator::GeometryEntry> sorted = entries;

    for (auto &entry : sorted) {
        if (entry.firstId > entry.secondId)
            std::swap(entry.firstId, entry.secondId);
    }

    std::stable_sort(sorted.begin(), sorted.end(), [](const auto &a, const auto &b) {
        const int fileComparison = QString::compare(a.fileName, b.fileName, Qt::CaseInsensitive);
        if (fileComparison != 0)
            return fileComparison < 0;
        if (a.pairIndex != b.pairIndex)
            return a.pairIndex < b.pairIndex;
        if (a.firstId != b.firstId)
            return a.firstId < b.firstId;
        return a.secondId < b.secondId;
    });

    return sorted;
}

QStringList buildRow(const BatchDivisionEstimator::GeometryEntry &entry,
                     const NeighborPairGeometrySettings &settings)
{
    QStringList row = {
        entry.fileName,
        QString::number(entry.pairIndex),
        QString::number(entry.firstId),
        QString::number(entry.secondId),
        entry.observedDivision ? QStringLiteral("1") : QStringLiteral("0"),
        QString::number(entry.observedDivision ? entry.divisionTime : -1),
        entry.exceptionLabel ? QStringLiteral("1") : QStringLiteral("0")
    };

    const auto &res = entry.geometry;

    if (settings.computeAreaRatio)
        row << formatValue(res.areaRatio);
    if (settings.computeAreaStats)
        row << formatValue(res.areaMean) << formatValue(res.areaMin) << formatValue(res.areaMax) << formatValue(res.areaDiff);

    if (settings.computePerimeterRatio)
        row << formatValue(res.perimeterRatio);
    if (settings.computePerimeterStats)
        row << formatValue(res.perimeterMean) << formatValue(res.perimeterMin) << formatValue(res.perimeterMax) << formatValue(res.perimeterDiff);

    if (settings.computeAspectRatio)
        row << formatValue(res.aspectRatio);
    if (settings.computeAspectRatioStats)
        row << formatValue(res.aspectMean) << formatValue(res.aspectMin) << formatValue(res.aspectMax) << formatValue(res.aspectDiff);

    if (settings.computeCircularityRatio)
        row << formatValue(res.circularityRatio);
    if (settings.computeCircularityStats)
        row << formatValue(res.circularityMean) << formatValue(res.circularityMin) << formatValue(res.circularityMax) << formatValue(res.circularityDiff);

    if (settings.computeSolidityRatio)
        row << formatValue(res.solidityRatio);
    if (settings.computeSolidityStats)
        row << formatValue(res.solidityMean) << formatValue(res.solidityMin) << formatValue(res.solidityMax) << formatValue(res.solidityDiff);

    if (settings.computeVertexCountRatio)
        row << formatValue(res.vertexCountRatio);
    if (settings.computeVertexCountStats)
        row << formatValue(res.vertexCountMean) << formatValue(res.vertexCountMin) << formatValue(res.vertexCountMax) << formatValue(res.vertexCountDiff);

    if (settings.computeCentroidDistance)
        row << formatValue(res.centroidDistance) << formatValue(res.centroidDistanceNormalized);

    if (settings.computeUnionAspectRatio)
        row << formatValue(res.unionAspectRatio);
    if (settings.computeUnionCircularity)
        row << formatValue(res.unionCircularity);
    if (settings.computeUnionConvexDeficiency)
        row << formatValue(res.unionConvexDeficiency);

    if (settings.computeNormalizedSharedEdgeLength)
        row << formatValue(res.normalizedSharedEdgeLength) << formatValue(res.sharedEdgeLength);

    if (settings.computeSharedEdgeUnsharedVerticesDistance)
        row << formatValue(res.sharedEdgeUnsharedVerticesDistance);
    if (settings.computeSharedEdgeUnsharedVerticesDistanceNormalized)
        row << formatValue(res.sharedEdgeUnsharedVerticesDistanceNormalized);

    if (settings.computeCentroidSharedEdgeDistance)
        row << formatValue(res.centroidSharedEdgeDistance);
    if (settings.computeCentroidSharedEdgeDistanceNormalized)
        row << formatValue(res.centroidSharedEdgeDistanceNormalized);

    if (settings.computeSharedEdgeUnionCentroidDistance)
        row << formatValue(res.sharedEdgeUnionCentroidDistance);
    if (settings.computeSharedEdgeUnionCentroidDistanceNormalized)
        row << formatValue(res.sharedEdgeUnionCentroidDistanceNormalized);
    if (settings.computeSharedEdgeUnionAxisAngle)
        row << formatValue(res.sharedEdgeUnionAxisAngleDegrees);

    if (settings.computeJunctionAngleAverage)
        row << formatValue(res.junctionAngleAverageDegrees);
    if (settings.computeJunctionAngleMax)
        row << formatValue(res.junctionAngleMaxDegrees);
    if (settings.computeJunctionAngleMin)
        row << formatValue(res.junctionAngleMinDegrees);
    if (settings.computeJunctionAngleDifference)
        row << formatValue(res.junctionAngleDifferenceDegrees);
    if (settings.computeJunctionAngleRatio)
        row << formatValue(res.junctionAngleRatio);

    return row;
}

QStringList buildSingleCellHeaders()
{
    return {
        "fileName",
        "polygonId",
        "inDividingPair",
        "area",
        "perimeter",
        "aspectRatio",
        "circularity",
        "solidity",
        "vertexCount"
    };
}

QStringList buildSingleCellRow(const BatchDivisionEstimator::SingleCellGeometryEntry &entry)
{
    return {
        entry.fileName,
        QString::number(entry.polygonId),
        entry.inDividingPair ? QStringLiteral("1") : QStringLiteral("0"),
        formatValue(entry.area),
        formatValue(entry.perimeter),
        formatValue(entry.aspectRatio),
        formatValue(entry.circularity),
        formatValue(entry.solidity),
        QString::number(entry.vertexCount)
    };
}

QString escapeForCsv(const QString &value)
{
    QString escaped = value;
    escaped.replace('"', "\"\"");
    if (escaped.contains(',') || escaped.contains('"') || escaped.contains('\n'))
        escaped = QStringLiteral("\"%1\"").arg(escaped);
    return escaped;
}

QStringList parseCsvLine(const QString &line)
{
    QStringList fields;
    QString current;
    bool inQuotes = false;
    for (int i = 0; i < line.size(); ++i) {
        const QChar ch = line.at(i);
        if (ch == '"') {
            if (inQuotes && i + 1 < line.size() && line.at(i + 1) == '"') {
                current.append('"');
                ++i;
            } else {
                inQuotes = !inQuotes;
            }
        } else if (ch == ',' && !inQuotes) {
            fields.append(current.trimmed());
            current.clear();
        } else {
            current.append(ch);
        }
    }
    fields.append(current.trimmed());
    return fields;
}

QStringList divisionCsvHeaders()
{
    return {
        "filename",
        "cell_1_id",
        "cell_2_id",
        "division_timing",
        "observed_division",
        "estimated_division",
        "distance",
        "distance_normalized",
        "area_ratio",
        "area_diff",
        "convex_deficiency",
        "area_min",
        "area_max",
        "area_mean",
        "perimeter_ratio",
        "perimeter_min",
        "perimeter_max",
        "perimeter_mean",
        "perimeter_diff",
        "aspect_ratio",
        "compactness_min",
        "compactness_max",
        "compactness_mean",
        "compactness_diff",
        "elongation_ratio",
        "elongation_min",
        "elongation_max",
        "elongation_mean",
        "elongation_diff",
        "solidity_ratio",
        "solidity_min",
        "solidity_max",
        "solidity_mean",
        "solidity_diff",
        "vertex_count_ratio",
        "vertex_count_min",
        "vertex_count_max",
        "vertex_count_mean",
        "vertex_count_diff",
        "union_aspect_ratio",
        "union_circularity",
        "shared_edge_length",
        "shared_edge_length_normalized",
        "shared_edge_vertex_distance",
        "shared_edge_vertex_distance_normalized",
        "centroid_shared_edge_distance",
        "centroid_shared_edge_distance_normalized",
        "union_centroid_edge_distance",
        "union_centroid_edge_distance_normalized",
        "union_axis_shared_edge_angle",
        "junction_angle_ratio",
        "junction_angle_diff",
        "junction_angle_min",
        "junction_angle_max",
        "junction_angle_mean"
    };
}

QStringList buildDivisionCsvRow(const BatchDivisionEstimator::DivisionPairRow &row)
{
    const auto &geom = row.geometry;
    QStringList values = {
        row.fileName,
        QString::number(row.firstId),
        QString::number(row.secondId),
        QString::number(row.divisionTime),
        row.observedDivision ? QStringLiteral("1") : QStringLiteral("0"),
        row.estimatedDivision ? QStringLiteral("1") : QStringLiteral("0"),
        formatValue(geom.centroidDistance),
        formatValue(geom.centroidDistanceNormalized),
        formatValue(geom.areaRatio),
        formatValue(geom.areaDiff),
        formatValue(geom.unionConvexDeficiency),
        formatValue(geom.areaMin),
        formatValue(geom.areaMax),
        formatValue(geom.areaMean),
        formatValue(geom.perimeterRatio),
        formatValue(geom.perimeterMin),
        formatValue(geom.perimeterMax),
        formatValue(geom.perimeterMean),
        formatValue(geom.perimeterDiff),
        formatValue(geom.aspectRatio),
        formatValue(geom.circularityMin),
        formatValue(geom.circularityMax),
        formatValue(geom.circularityMean),
        formatValue(geom.circularityDiff),
        formatValue(geom.aspectRatio),
        formatValue(geom.aspectMin),
        formatValue(geom.aspectMax),
        formatValue(geom.aspectMean),
        formatValue(geom.aspectDiff),
        formatValue(geom.solidityRatio),
        formatValue(geom.solidityMin),
        formatValue(geom.solidityMax),
        formatValue(geom.solidityMean),
        formatValue(geom.solidityDiff),
        formatValue(geom.vertexCountRatio),
        formatValue(geom.vertexCountMin),
        formatValue(geom.vertexCountMax),
        formatValue(geom.vertexCountMean),
        formatValue(geom.vertexCountDiff),
        formatValue(geom.unionAspectRatio),
        formatValue(geom.unionCircularity),
        formatValue(geom.sharedEdgeLength),
        formatValue(geom.normalizedSharedEdgeLength),
        formatValue(geom.sharedEdgeUnsharedVerticesDistance),
        formatValue(geom.sharedEdgeUnsharedVerticesDistanceNormalized),
        formatValue(geom.centroidSharedEdgeDistance),
        formatValue(geom.centroidSharedEdgeDistanceNormalized),
        formatValue(geom.sharedEdgeUnionCentroidDistance),
        formatValue(geom.sharedEdgeUnionCentroidDistanceNormalized),
        formatValue(geom.sharedEdgeUnionAxisAngleDegrees),
        formatValue(geom.junctionAngleRatio),
        formatValue(geom.junctionAngleDifferenceDegrees),
        formatValue(geom.junctionAngleMinDegrees),
        formatValue(geom.junctionAngleMaxDegrees),
        formatValue(geom.junctionAngleAverageDegrees)
    };
    return values;
}

QString normalizedPairKey(int a, int b)
{
    const int first = std::min(a, b);
    const int second = std::max(a, b);
    return QString("%1-%2").arg(first).arg(second);
}

QSet<QString> pairKeys(const QVector<QPair<int, int>> &pairs)
{
    QSet<QString> keys;
    for (const auto &pair : pairs)
        keys.insert(normalizedPairKey(pair.first, pair.second));
    return keys;
}

QString normalizeFeatureName(const QString &value)
{
    QString normalized = value.trimmed().toLower();
    normalized.remove(QRegularExpression("[^a-z0-9]+"));
    return normalized;
}

QString featureKeyFromName(const QString &name)
{
    const QString normalized = normalizeFeatureName(name);
    if (normalized.isEmpty())
        return {};

    const QHash<QString, QString> manualMap = {
        {"junctionanglemean", "junctionAngleAverageDegrees"},
        {"junctionangleaverage", "junctionAngleAverageDegrees"},
        {"junctionangleavg", "junctionAngleAverageDegrees"},
        {"junctionanglemin", "junctionAngleMinDegrees"},
        {"junctionanglemax", "junctionAngleMaxDegrees"},
        {"junctionanglediff", "junctionAngleDifferenceDegrees"},
        {"junctionangledifference", "junctionAngleDifferenceDegrees"},
        {"junctionangleratio", "junctionAngleRatio"}
    };
    if (manualMap.contains(normalized))
        return manualMap.value(normalized);

    const QVector<DivisionEstimator::FeatureOption> options = DivisionEstimator::featureOptions();
    for (const auto &opt : options) {
        const QString normalizedKey = normalizeFeatureName(opt.key);
        const QString normalizedLabel = normalizeFeatureName(opt.label);
        if (normalizedKey == normalized || normalizedLabel == normalized)
            return opt.key;
        QString simplifiedLabel = normalizedLabel;
        simplifiedLabel.remove("degrees");
        simplifiedLabel.remove("degree");
        simplifiedLabel.remove("deg");
        if (simplifiedLabel == normalized)
            return opt.key;
    }

    return {};
}

QHash<QString, QSet<QString>> loadExceptionCsv(const QFileInfo &exceptionFile, QStringList *warnings)
{
    QHash<QString, QSet<QString>> map;
    QFile file(exceptionFile.absoluteFilePath());
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        if (warnings)
            warnings->append(QString("Failed to open %1: %2").arg(exceptionFile.fileName(), file.errorString()));
        return map;
    }

    QTextStream in(&file);
    int lineNumber = 0;
    while (!in.atEnd()) {
        const QString rawLine = in.readLine();
        ++lineNumber;
        const QString line = rawLine.trimmed();
        if (line.isEmpty())
            continue;

        const QStringList parts = line.split(QRegularExpression("[,;\\s]+"), Qt::SkipEmptyParts);
        if (parts.size() < 3) {
            if (warnings)
                warnings->append(QString("%1 line %2: expected filename and two ids").arg(exceptionFile.fileName()).arg(lineNumber));
            continue;
        }

        const QString fileName = parts.at(0).trimmed();
        bool okFirst = false;
        bool okSecond = false;
        const int firstId = parts.at(1).toInt(&okFirst);
        const int secondId = parts.at(2).toInt(&okSecond);
        if (fileName.isEmpty() || !okFirst || !okSecond) {
            if (warnings)
                warnings->append(QString("%1 line %2: invalid values").arg(exceptionFile.fileName()).arg(lineNumber));
            continue;
        }

        map[fileName].insert(normalizedPairKey(firstId, secondId));
    }

    return map;
}

NeighborPairGeometrySettings exportSettingsForDivisionCsv(const DivisionEstimator::Criterion &criterion)
{
    NeighborPairGeometrySettings settings = criterion.settings;
    settings.computeAreaRatio = true;
    settings.computeAreaStats = true;
    settings.computePerimeterRatio = true;
    settings.computePerimeterStats = true;
    settings.computeAspectRatio = true;
    settings.computeAspectRatioStats = true;
    settings.computeCircularityRatio = true;
    settings.computeCircularityStats = true;
    settings.computeSolidityRatio = true;
    settings.computeSolidityStats = true;
    settings.computeVertexCountRatio = true;
    settings.computeVertexCountStats = true;
    settings.computeCentroidDistance = true;
    settings.computeUnionAspectRatio = true;
    settings.computeUnionCircularity = true;
    settings.computeUnionConvexDeficiency = true;
    settings.computeNormalizedSharedEdgeLength = true;
    settings.computeSharedEdgeUnsharedVerticesDistance = true;
    settings.computeSharedEdgeUnsharedVerticesDistanceNormalized = true;
    settings.computeCentroidSharedEdgeDistance = true;
    settings.computeCentroidSharedEdgeDistanceNormalized = true;
    settings.computeSharedEdgeUnionCentroidDistance = true;
    settings.computeSharedEdgeUnionCentroidDistanceNormalized = true;
    settings.computeSharedEdgeUnionAxisAngle = true;
    settings.computeJunctionAngleAverage = true;
    settings.computeJunctionAngleMax = true;
    settings.computeJunctionAngleMin = true;
    settings.computeJunctionAngleDifference = true;
    settings.computeJunctionAngleRatio = true;
    return settings;
}

QString findRealDivisionFile(const QDir &dir, const QFileInfo &jsonFile)
{
    const QString baseName = jsonFile.completeBaseName();
    const QStringList candidates = {
        dir.filePath(baseName + "_real_division_pairs.csv"),
        dir.filePath(baseName + "_real_division_pairs.txt"),
        dir.filePath(baseName + ".csv")
    };

    for (const QString &path : candidates) {
        QFileInfo info(path);
        if (info.exists() && info.isFile())
            return info.absoluteFilePath();
    }

    return {};
}

struct RealDivisionEntry {
    int firstId = -1;
    int secondId = -1;
    int time = -1;
};

QVector<RealDivisionEntry> readDivisionPairs(const QString &filePath, QStringList &warnings)
{
    QVector<RealDivisionEntry> pairs;
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        warnings << QString("Failed to open %1: %2").arg(QFileInfo(filePath).fileName(),
                                                        file.errorString());
        return pairs;
    }

    QTextStream in(&file);
    int lineNumber = 0;
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        ++lineNumber;

        if (line.isEmpty())
            continue;

        if (isRealDivisionHeader(line)) {
            // Files may contain a format marker followed by a column-name row.
            continue;
        }

        const QStringList parts = line.split(QRegularExpression("[,;\\s]+"), Qt::SkipEmptyParts);
        if (parts.size() < 2) {
            warnings << QString("Line %1: Expected at least two integers.").arg(lineNumber);
            continue;
        }

        bool okFirst = false;
        bool okSecond = false;
        bool okTime = true;
        const int firstId = parts.at(0).toInt(&okFirst);
        const int secondId = parts.at(1).toInt(&okSecond);
        int time = -1;
        if (parts.size() >= 3)
            time = parts.at(2).toInt(&okTime);

        if (!okFirst || !okSecond) {
            warnings << QString("Line %1: Unable to parse integers.").arg(lineNumber);
            continue;
        }
        if (!okTime && parts.size() >= 3)
            warnings << QString("Line %1: Unable to parse division time value, defaulting to -1.").arg(lineNumber);

        RealDivisionEntry entry;
        entry.firstId = firstId;
        entry.secondId = secondId;
        entry.time = okTime ? time : -1;
        pairs.append(entry);
    }

    return pairs;
}

QVector<QPair<int, int>> neighborPairs(QGraphicsScene *scene, const QVector<PolygonItem*> &polygons)
{
    QVector<QPair<int, int>> pairs = GeometryIO::neighborPairsFromScene(scene);
    if (!pairs.isEmpty())
        return pairs;
    return computeNeighborPairs(polygons);
}

double aspectRatioForPolygon(const PolygonItem *item)
{
    if (!item)
        return -1.0;
    const QRectF bounds = item->polygon().boundingRect();
    if (bounds.height() <= 0.0 || bounds.width() <= 0.0)
        return -1.0;
    const double ratio = bounds.width() / bounds.height();
    return ratio >= 1.0 ? ratio : 1.0 / ratio;
}

double circularityForPolygon(const PolygonItem *item)
{
    if (!item)
        return -1.0;
    const double area = item->area();
    const double per = item->perimeter();
    if (area <= 0.0 || per <= 0.0)
        return -1.0;
    return (4.0 * M_PI * area) / (per * per);
}

double polygonArea(const QPolygonF &p)
{
    const int n = p.size();
    if (n < 3)
        return 0.0;

    double area = 0.0;
    for (int i = 0; i < n; ++i) {
        const QPointF &a = p[i];
        const QPointF &b = p[(i + 1) % n];
        area += a.x() * b.y() - b.x() * a.y();
    }
    return std::abs(area) * 0.5;
}

QPolygonF convexHull(const QPolygonF &points)
{
    QVector<QPointF> pts(points.begin(), points.end());
    if (pts.size() < 3)
        return QPolygonF(pts);

    const auto cross = [](const QPointF &a, const QPointF &b, const QPointF &c) {
        return (b.x() - a.x()) * (c.y() - a.y()) - (b.y() - a.y()) * (c.x() - a.x());
    };

    std::sort(pts.begin(), pts.end(), [](const QPointF &lhs, const QPointF &rhs) {
        if (lhs.x() == rhs.x())
            return lhs.y() < rhs.y();
        return lhs.x() < rhs.x();
    });

    QVector<QPointF> lower;
    for (const QPointF &p : pts) {
        while (lower.size() >= 2 && cross(lower[lower.size() - 2], lower.last(), p) <= 0)
            lower.removeLast();
        lower.append(p);
    }

    QVector<QPointF> upper;
    for (int i = pts.size() - 1; i >= 0; --i) {
        const QPointF &p = pts[i];
        while (upper.size() >= 2 && cross(upper[upper.size() - 2], upper.last(), p) <= 0)
            upper.removeLast();
        upper.append(p);
    }

    lower.pop_back();
    upper.pop_back();
    lower += upper;
    return QPolygonF(lower);
}

double solidityForPolygon(const PolygonItem *item)
{
    if (!item)
        return -1.0;
    const QPolygonF poly = item->polygon();
    if (poly.isEmpty())
        return -1.0;

    const double area = item->area();
    const double hullArea = polygonArea(convexHull(poly));
    if (area <= 0.0 || hullArea <= 0.0)
        return -1.0;
    return area / hullArea;
}

NeighborPairGeometryCalculator::Result geometryFromCsv(const QStringList &fields,
                                                        const QHash<QString, int> &columns)
{
    NeighborPairGeometryCalculator::Result result;
    const auto value = [&fields, &columns](const char *name) {
        const int index = columns.value(QString::fromLatin1(name).toLower(), -1);
        bool ok = false;
        const double parsed = index >= 0 && index < fields.size() ? fields.at(index).trimmed().toDouble(&ok) : 0.0;
        return ok ? parsed : std::numeric_limits<double>::quiet_NaN();
    };
#define READ_GEOMETRY(member) result.member = value(#member)
    READ_GEOMETRY(areaRatio); READ_GEOMETRY(areaMean); READ_GEOMETRY(areaMin); READ_GEOMETRY(areaMax); READ_GEOMETRY(areaDiff);
    READ_GEOMETRY(perimeterRatio); READ_GEOMETRY(perimeterMean); READ_GEOMETRY(perimeterMin); READ_GEOMETRY(perimeterMax); READ_GEOMETRY(perimeterDiff);
    READ_GEOMETRY(aspectRatio); READ_GEOMETRY(aspectMean); READ_GEOMETRY(aspectMin); READ_GEOMETRY(aspectMax); READ_GEOMETRY(aspectDiff);
    READ_GEOMETRY(circularityRatio); READ_GEOMETRY(circularityMean); READ_GEOMETRY(circularityMin); READ_GEOMETRY(circularityMax); READ_GEOMETRY(circularityDiff);
    READ_GEOMETRY(solidityRatio); READ_GEOMETRY(solidityMean); READ_GEOMETRY(solidityMin); READ_GEOMETRY(solidityMax); READ_GEOMETRY(solidityDiff);
    READ_GEOMETRY(vertexCountRatio); READ_GEOMETRY(vertexCountMean); READ_GEOMETRY(vertexCountMin); READ_GEOMETRY(vertexCountMax); READ_GEOMETRY(vertexCountDiff);
    READ_GEOMETRY(centroidDistance); READ_GEOMETRY(centroidDistanceNormalized);
    READ_GEOMETRY(unionAspectRatio); READ_GEOMETRY(unionCircularity); READ_GEOMETRY(unionConvexDeficiency);
    READ_GEOMETRY(normalizedSharedEdgeLength); READ_GEOMETRY(sharedEdgeLength);
    READ_GEOMETRY(sharedEdgeUnsharedVerticesDistance); READ_GEOMETRY(sharedEdgeUnsharedVerticesDistanceNormalized);
    READ_GEOMETRY(centroidSharedEdgeDistance); READ_GEOMETRY(centroidSharedEdgeDistanceNormalized);
    READ_GEOMETRY(sharedEdgeUnionCentroidDistance); READ_GEOMETRY(sharedEdgeUnionCentroidDistanceNormalized);
    READ_GEOMETRY(sharedEdgeUnionAxisAngleDegrees);
    READ_GEOMETRY(junctionAngleAverageDegrees); READ_GEOMETRY(junctionAngleMaxDegrees);
    READ_GEOMETRY(junctionAngleMinDegrees); READ_GEOMETRY(junctionAngleDifferenceDegrees); READ_GEOMETRY(junctionAngleRatio);
#undef READ_GEOMETRY
    return result;
}

} // namespace

BatchDivisionEstimator::GeometrySummary BatchDivisionEstimator::processNeighborGeometryDirectory(
        const QString &directoryPath,
        const QString &realDivisionDirectoryPath,
        const NeighborPairGeometrySettings &settings,
        const GeometryProgressCallback &progressCallback)
{
    GeometrySummary summary;
    QDir dir(directoryPath);
    if (!dir.exists()) {
        summary.errors << QString("Directory does not exist: %1").arg(directoryPath);
        return summary;
    }

    const QDir realDivisionDir(realDivisionDirectoryPath);
    if (!realDivisionDir.exists()) {
        summary.errors << QString("Real division pair directory does not exist: %1").arg(realDivisionDirectoryPath);
        return summary;
    }

    const QFileInfoList files = dir.entryInfoList(QStringList() << "*.json", QDir::Files | QDir::Readable, QDir::Name);
    if (files.isEmpty()) {
        summary.warnings << QString("No .json files found in %1").arg(directoryPath);
        return summary;
    }

    if (progressCallback)
        progressCallback(0, files.size(), QString(), 0, 0);

    QStringList exceptionWarnings;
    const QHash<QString, QSet<QString>> exceptions = loadExceptionPairs(realDivisionDir, &exceptionWarnings);
    summary.warnings.append(exceptionWarnings);

    for (const QFileInfo &info : files) {
        if (progressCallback)
            progressCallback(summary.filesProcessed, files.size(), info.fileName(), 0, 0);
        ++summary.filesProcessed;
        GeometryImportResult importResult = GeometryIO::importFromJson(info.absoluteFilePath(), false);
        if (!importResult.success || !importResult.scene) {
            summary.errors << QString("Failed to import %1: %2")
                              .arg(info.fileName())
                              .arg(importResult.errorMessage.isEmpty() ? QStringLiteral("Unknown error") : importResult.errorMessage);
            continue;
        }

        std::unique_ptr<QGraphicsScene> scene(importResult.scene);
        const QVector<PolygonItem*> polygons = collectPolygons(scene.get());
        if (polygons.size() < 2) {
            summary.warnings << QString("%1: requires at least two polygons for neighbor calculation.").arg(info.fileName());
            continue;
        }

        const QHash<int, PolygonItem*> polygonsById = polygonMap(polygons);
        QVector<QPair<int, int>> pairs = neighborPairs(scene.get(), polygons);

        QStringList parseWarnings;
        QHash<QString, int> realPairTimes;
        QSet<QString> realPairKeys;
        const QSet<QString> exceptionKeys = exceptionPairsForFile(info, exceptions);
        const QString realDivisionFile = findRealDivisionFile(realDivisionDir, info);
        if (realDivisionFile.isEmpty()) {
            summary.warnings << QString("%1: no matching real division pair file found in %2.")
                                .arg(info.fileName(), realDivisionDir.absolutePath());
        } else {
            const QVector<RealDivisionEntry> realPairs = readDivisionPairs(realDivisionFile, parseWarnings);
            for (const RealDivisionEntry &pair : realPairs) {
                const QString key = normalizedPairKey(pair.firstId, pair.secondId);
                realPairKeys.insert(key);
                realPairTimes.insert(key, pair.time);
            }
            if (realPairs.isEmpty()) {
                summary.warnings << QString("%1: no valid real division pairs found in %2")
                                    .arg(info.fileName())
                                    .arg(QFileInfo(realDivisionFile).fileName());
            }
        }

        if (pairs.isEmpty()) {
            summary.warnings << QString("%1: no neighboring polygons detected.").arg(info.fileName());
            continue;
        }

        if (progressCallback)
            progressCallback(summary.filesProcessed, files.size(), info.fileName(), 0, pairs.size());

        int pairIndex = 0;
        for (int pairPosition = 0; pairPosition < pairs.size(); ++pairPosition) {
            const auto &pair = pairs.at(pairPosition);
            PolygonItem *first = polygonsById.value(pair.first, nullptr);
            PolygonItem *second = polygonsById.value(pair.second, nullptr);
            if (!first || !second) {
                summary.warnings << QString("%1: neighbor pair (%2, %3) references missing polygons.")
                                    .arg(info.fileName())
                                    .arg(pair.first)
                                    .arg(pair.second);
                if (progressCallback)
                    progressCallback(summary.filesProcessed, files.size(), info.fileName(), pairPosition + 1, pairs.size());
                continue;
            }

            NeighborPairGeometryCalculator::Result result = NeighborPairGeometryCalculator::calculateForPair(first, second, settings);
            result.first = nullptr;
            result.second = nullptr;

            GeometryEntry entry;
            entry.fileName = info.fileName();
            entry.pairIndex = ++pairIndex;
            entry.firstId = first->id();
            entry.secondId = second->id();
            const QString neighborKey = normalizedPairKey(entry.firstId, entry.secondId);
            entry.observedDivision = realPairKeys.contains(neighborKey);
            entry.divisionTime = entry.observedDivision ? realPairTimes.value(neighborKey, -1) : -1;
            entry.exceptionLabel = exceptionKeys.contains(neighborKey);
            entry.geometry = result;

            summary.entries.append(entry);

            if (progressCallback)
                progressCallback(summary.filesProcessed, files.size(), info.fileName(), pairPosition + 1, pairs.size());
        }

        if (pairIndex > 0)
            ++summary.filesWithResults;

        for (const QString &warn : std::as_const(parseWarnings))
            summary.warnings << QString("%1: %2").arg(info.fileName(), warn);

    }

    if (progressCallback)
        progressCallback(summary.filesProcessed, files.size(), QString(), 0, 0);

    return summary;
}

bool BatchDivisionEstimator::exportNeighborGeometryToCsv(const QString &filePath,
                                                         const QVector<GeometryEntry> &entries,
                                                         const NeighborPairGeometrySettings &settings,
                                                         QString *errorMessage)
{
    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        if (errorMessage)
            *errorMessage = QString("Unable to open %1 for writing").arg(filePath);
        return false;
    }

    QTextStream stream(&file);
    const QStringList headers = buildHeaders(settings);
    stream << headers.join(',') << '\n';

    const QVector<GeometryEntry> sortedEntries = sortedNormalizedGeometryEntries(entries);
    for (const GeometryEntry &entry : sortedEntries) {
        QStringList row = buildRow(entry, settings);
        for (QString &field : row)
            field = escapeForCsv(field);
        stream << row.join(',') << '\n';
    }

    return true;
}

BatchDivisionEstimator::SingleCellGeometrySummary BatchDivisionEstimator::processSingleCellGeometryDirectory(const QString &directoryPath)
{
    SingleCellGeometrySummary summary;
    QDir dir(directoryPath);
    if (!dir.exists()) {
        summary.errors << QString("Directory does not exist: %1").arg(directoryPath);
        return summary;
    }

    const QFileInfoList files = dir.entryInfoList(QStringList() << "*.json", QDir::Files | QDir::Readable, QDir::Name);
    if (files.isEmpty()) {
        summary.warnings << QString("No .json files found in %1").arg(directoryPath);
        return summary;
    }

    for (const QFileInfo &info : files) {
        ++summary.filesProcessed;
        GeometryImportResult importResult = GeometryIO::importFromJson(info.absoluteFilePath(), false);
        if (!importResult.success || !importResult.scene) {
            summary.errors << QString("Failed to import %1: %2")
                              .arg(info.fileName())
                              .arg(importResult.errorMessage.isEmpty() ? QStringLiteral("Unknown error") : importResult.errorMessage);
            continue;
        }

        std::unique_ptr<QGraphicsScene> scene(importResult.scene);
        const QVector<PolygonItem*> polygons = collectPolygons(scene.get());
        if (polygons.isEmpty()) {
            summary.warnings << QString("%1: no polygons detected.").arg(info.fileName());
            continue;
        }

        QStringList parseWarnings;
        QSet<int> dividingCellIds;
        const QString realDivisionFile = findRealDivisionFile(dir, info);
        if (realDivisionFile.isEmpty()) {
            summary.warnings << QString("%1: no matching *_real_division_pairs.csv file found.").arg(info.fileName());
        } else {
            const QVector<RealDivisionEntry> realPairs = readDivisionPairs(realDivisionFile, parseWarnings);
            for (const RealDivisionEntry &pair : realPairs) {
                dividingCellIds.insert(pair.firstId);
                dividingCellIds.insert(pair.secondId);
            }
            if (realPairs.isEmpty()) {
                summary.warnings << QString("%1: no valid real division pairs found in %2")
                                    .arg(info.fileName())
                                    .arg(QFileInfo(realDivisionFile).fileName());
            }
        }

        int rowsAdded = 0;
        for (PolygonItem *poly : polygons) {
            if (!poly)
                continue;

            SingleCellGeometryEntry entry;
            entry.fileName = info.fileName();
            entry.polygonId = poly->id();
            entry.inDividingPair = dividingCellIds.contains(entry.polygonId);
            entry.area = poly->area();
            entry.perimeter = poly->perimeter();
            entry.aspectRatio = aspectRatioForPolygon(poly);
            entry.circularity = circularityForPolygon(poly);
            entry.solidity = solidityForPolygon(poly);
            entry.vertexCount = poly->vertices().size();

            summary.entries.append(entry);
            ++rowsAdded;
        }

        if (rowsAdded > 0)
            ++summary.filesWithResults;

        for (const QString &warn : std::as_const(parseWarnings))
            summary.warnings << QString("%1: %2").arg(info.fileName(), warn);
    }

    return summary;
}

bool BatchDivisionEstimator::exportSingleCellGeometryToCsv(const QString &filePath,
                                                           const QVector<SingleCellGeometryEntry> &entries,
                                                           QString *errorMessage)
{
    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        if (errorMessage)
            *errorMessage = QString("Unable to open %1 for writing").arg(filePath);
        return false;
    }

    QTextStream stream(&file);
    QStringList headers = buildSingleCellHeaders();
    for (QString &header : headers)
        header = escapeForCsv(header);
    stream << headers.join(',') << '\n';

    for (const SingleCellGeometryEntry &entry : entries) {
        QStringList row = buildSingleCellRow(entry);
        for (QString &field : row)
            field = escapeForCsv(field);
        stream << row.join(',') << '\n';
    }

    return true;
}

bool BatchDivisionEstimator::exportDivisionEstimatesToCsv(const QString &filePath,
                                                          const QVector<DivisionPairRow> &rows,
                                                          QString *errorMessage)
{
    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        if (errorMessage)
            *errorMessage = QString("Unable to open %1 for writing").arg(filePath);
        return false;
    }

    QTextStream stream(&file);
    QStringList headers = divisionCsvHeaders();
    for (QString &header : headers)
        header = escapeForCsv(header);
    stream << headers.join(',') << '\n';

    for (const DivisionPairRow &row : rows) {
        QStringList fields = buildDivisionCsvRow(row);
        for (QString &field : fields)
            field = escapeForCsv(field);
        stream << fields.join(',') << '\n';
    }

    return true;
}

bool BatchDivisionEstimator::exportPerformanceMatrixFigure(const QString &filePath,
                                                               const DivisionMetrics &metrics,
                                                               QString *errorMessage)
{
    constexpr int width = 847;
    constexpr int height = 612;
    constexpr int lineWidth = 5;
    QImage image(width, height, QImage::Format_RGB32);
    image.fill(Qt::white);

    QPainter painter(&image);
    painter.setRenderHint(QPainter::Antialiasing, true);
    painter.setRenderHint(QPainter::TextAntialiasing, true);
    const QPen borderPen(Qt::black, lineWidth);

    const QColor peach(251, 227, 214);
    const QColor red(218, 103, 82);
    const QColor blue(76, 121, 162);
    const QColor tpFill(252, 220, 214);
    const QColor fpFill(234, 242, 228);
    const QColor fnFill(225, 233, 241);
    const QColor tnFill(218, 212, 235);
    const QColor grey(232, 232, 232);

    const QRect observedBox(350, 15, 490, 83);
    const QRect colDaughterBox(350, 96, 245, 109);
    const QRect colNonDaughterBox(595, 96, 245, 109);
    const QRect estimatedBox(15, 203, 95, 282);
    const QRect rowDaughterBox(110, 203, 240, 142);
    const QRect rowNonDaughterBox(110, 345, 240, 140);
    const QRect tpBox(350, 203, 245, 142);
    const QRect fpBox(595, 203, 245, 142);
    const QRect fnBox(350, 345, 245, 140);
    const QRect tnBox(595, 345, 245, 140);
    const QRect precisionBox(15, 518, 275, 82);
    const QRect recallBox(290, 518, 275, 82);
    const QRect f1Box(565, 518, 275, 82);

    const auto drawBox = [&painter, &borderPen](const QRect &box, const QColor &fill) {
        painter.setPen(borderPen);
        painter.setBrush(fill);
        painter.drawRect(box);
    };
    drawBox(observedBox, peach); drawBox(colDaughterBox, red); drawBox(colNonDaughterBox, blue);
    drawBox(estimatedBox, peach); drawBox(rowDaughterBox, red); drawBox(rowNonDaughterBox, blue);
    drawBox(tpBox, tpFill); drawBox(fpBox, fpFill); drawBox(fnBox, fnFill); drawBox(tnBox, tnFill);
    drawBox(precisionBox, grey); drawBox(recallBox, grey); drawBox(f1Box, grey);

    QFont font(QStringLiteral("Arial"));
    font.setStyleHint(QFont::SansSerif);
    font.setPixelSize(31);
    painter.setFont(font);
    const auto drawText = [&painter](const QRect &box, const QString &text, const QColor &color) {
        painter.setPen(color);
        painter.drawText(box.adjusted(8, 5, -8, -5), Qt::AlignCenter | Qt::TextWordWrap, text);
    };
    drawText(observedBox, QStringLiteral("Observed"), Qt::black);
    drawText(colDaughterBox, QStringLiteral("Daughter Pair"), Qt::white);
    drawText(colNonDaughterBox, QStringLiteral("Non-Daughter\nPair"), Qt::white);
    drawText(rowDaughterBox, QStringLiteral("Daughter Pair"), Qt::white);
    drawText(rowNonDaughterBox, QStringLiteral("Non-Daughter\nPair"), Qt::white);

    painter.save();
    painter.translate(estimatedBox.center());
    painter.rotate(-90.0);
    drawText(QRect(-estimatedBox.height() / 2, -estimatedBox.width() / 2,
                   estimatedBox.height(), estimatedBox.width()), QStringLiteral("Estimated"), Qt::black);
    painter.restore();

    drawText(tpBox, QString("True Positive\n(TP): %1").arg(metrics.truePositives), Qt::black);
    drawText(fpBox, QString("False Positive\n(FP): %1").arg(metrics.falsePositives), Qt::black);
    drawText(fnBox, QString("False Negative\n(FN): %1").arg(metrics.falseNegatives), Qt::black);
    drawText(tnBox, QString("True Negative\n(TN): %1").arg(metrics.trueNegatives), Qt::black);

    const auto percentage = [](double value) {
        return value >= 0.0 && std::isfinite(value)
                ? QString::number(value * 100.0, 'f', 1) + "%"
                : QStringLiteral("-");
    };
    drawText(precisionBox, QString("Precision: %1").arg(percentage(metrics.precision)), Qt::black);
    drawText(recallBox, QString("Recall: %1").arg(percentage(metrics.recall)), Qt::black);
    drawText(f1Box, QString("F1 score: %1").arg(percentage(metrics.f1)), Qt::black);
    painter.end();

    if (!image.save(filePath, "PNG", 100)) {
        if (errorMessage)
            *errorMessage = QString("Unable to save performance matrix PNG to %1").arg(filePath);
        return false;
    }
    return true;
}

BatchDivisionEstimator::DivisionMetrics BatchDivisionEstimator::metricsFromCounts(int neighborCount,
                                                                                  int truePositives,
                                                                                  int falsePositives,
                                                                                  int falseNegatives,
                                                                                  int estimatedCount,
                                                                                  int realCount)
{
    DivisionMetrics metrics;
    metrics.estimatedPairs = estimatedCount;
    metrics.realPairs = realCount;
    metrics.neighborPairs = neighborCount;
    metrics.truePositives = truePositives;
    metrics.falsePositives = falsePositives;
    metrics.falseNegatives = falseNegatives;
    metrics.trueNegatives = std::max(0, neighborCount - truePositives - falsePositives - falseNegatives);

    metrics.precision = (truePositives + falsePositives) > 0
            ? static_cast<double>(truePositives) / static_cast<double>(truePositives + falsePositives)
            : -1.0;
    metrics.recall = (truePositives + falseNegatives) > 0
            ? static_cast<double>(truePositives) / static_cast<double>(truePositives + falseNegatives)
            : -1.0;

    metrics.f1 = (metrics.precision >= 0.0 && metrics.recall >= 0.0 && (metrics.precision + metrics.recall) > 0.0)
            ? 2.0 * metrics.precision * metrics.recall / (metrics.precision + metrics.recall)
            : -1.0;

    metrics.specificity = (metrics.trueNegatives + falsePositives) > 0
            ? static_cast<double>(metrics.trueNegatives) / static_cast<double>(metrics.trueNegatives + falsePositives)
            : -1.0;

    metrics.accuracy = neighborCount > 0
            ? static_cast<double>(truePositives + metrics.trueNegatives) / static_cast<double>(neighborCount)
            : -1.0;

    return metrics;
}

BatchDivisionEstimator::DivisionMetrics BatchDivisionEstimator::calculateMetrics(const QVector<QPair<int, int>> &neighborPairs,
                                                                                 const QVector<QPair<int, int>> &estimatedPairs,
                                                                                 const QVector<QPair<int, int>> &realPairs)
{
    const QSet<QString> neighborKeys = pairKeys(neighborPairs);
    const QSet<QString> estimatedKeys = pairKeys(estimatedPairs);
    const QSet<QString> realKeys = pairKeys(realPairs);

    int truePositives = 0;
    int falsePositives = 0;
    int falseNegatives = 0;

    for (const QString &key : estimatedKeys) {
        if (realKeys.contains(key))
            ++truePositives;
        else
            ++falsePositives;
    }

    for (const QString &key : realKeys) {
        if (!estimatedKeys.contains(key))
            ++falseNegatives;
    }

    return metricsFromCounts(neighborKeys.size(),
                             truePositives,
                             falsePositives,
                             falseNegatives,
                             estimatedKeys.size(),
                             realKeys.size());
}

QHash<QString, QSet<QString>> BatchDivisionEstimator::loadExceptionPairs(const QDir &directory, QStringList *warnings)
{
    QFileInfo exceptionFile(directory.filePath("exception.csv"));
    if (!exceptionFile.exists() || !exceptionFile.isFile())
        return {};

    return loadExceptionCsv(exceptionFile, warnings);
}

QSet<QString> BatchDivisionEstimator::exceptionPairsForFile(const QFileInfo &fileInfo, const QHash<QString, QSet<QString>> &exceptionMap)
{
    QSet<QString> pairs = exceptionMap.value(fileInfo.fileName());
    if (pairs.isEmpty())
        pairs = exceptionMap.value(fileInfo.completeBaseName());
    return pairs;
}

BatchDivisionEstimator::BatchResult BatchDivisionEstimator::estimateDirectory(const QString &directoryPath,
                                                                              const DivisionEstimator::Criterion &criterion)
{
    BatchResult summary;
    int totalTruePositives = 0;
    int totalFalsePositives = 0;
    int totalFalseNegatives = 0;
    int totalNeighborPairs = 0;
    int totalEstimatedPairs = 0;
    int totalRealPairs = 0;
    const NeighborPairGeometrySettings geometrySettings = exportSettingsForDivisionCsv(criterion);

    QDir dir(directoryPath);
    if (!dir.exists()) {
        summary.errors << QString("Directory does not exist: %1").arg(directoryPath);
        return summary;
    }

    QStringList exceptionWarnings;
    const QHash<QString, QSet<QString>> exceptions = loadExceptionPairs(dir, &exceptionWarnings);
    summary.warnings.append(exceptionWarnings);

    const QFileInfoList files = dir.entryInfoList(QStringList() << "*.json", QDir::Files | QDir::Readable, QDir::Name);
    if (files.isEmpty()) {
        summary.warnings << QString("No .json files found in %1").arg(directoryPath);
        return summary;
    }

    for (const QFileInfo &info : files) {
        ++summary.filesProcessed;

        const QString realDivisionFile = findRealDivisionFile(dir, info);
        if (realDivisionFile.isEmpty()) {
            summary.warnings << QString("%1: no matching *_real_division_pairs.csv file found.").arg(info.fileName());
            continue;
        }

        GeometryImportResult importResult = GeometryIO::importFromJson(info.absoluteFilePath(), false);
        if (!importResult.success || !importResult.scene) {
            summary.errors << QString("Failed to import %1: %2")
                              .arg(info.fileName())
                              .arg(importResult.errorMessage.isEmpty() ? QStringLiteral("Unknown error") : importResult.errorMessage);
            continue;
        }

        std::unique_ptr<QGraphicsScene> scene(importResult.scene);
        const QVector<PolygonItem*> polygons = collectPolygons(scene.get());
        if (polygons.size() < 2) {
            summary.warnings << QString("%1: requires at least two polygons for division estimation.").arg(info.fileName());
            continue;
        }

        const QHash<int, PolygonItem*> polygonsById = polygonMap(polygons);
        QVector<QPair<int, int>> neighbors = neighborPairs(scene.get(), polygons);
        if (neighbors.isEmpty()) {
            summary.warnings << QString("%1: no neighboring polygons detected.").arg(info.fileName());
            continue;
        }

        const QSet<QString> exceptionKeys = exceptionPairsForFile(info, exceptions);
        QVector<QPair<int, int>> filteredNeighbors;
        filteredNeighbors.reserve(neighbors.size());
        for (const auto &neighbor : std::as_const(neighbors)) {
            if (exceptionKeys.contains(normalizedPairKey(neighbor.first, neighbor.second)))
                continue;
            filteredNeighbors.append(neighbor);
        }
        neighbors = filteredNeighbors;

        const DivisionEstimator::EstimationResult estimation = DivisionEstimator::estimatePairs(polygons, criterion, scene.get());
        QVector<QPair<int, int>> estimatedPairs = estimation.matchedPairIds;
        QVector<QPair<int, int>> filteredEstimatedPairs;
        filteredEstimatedPairs.reserve(estimatedPairs.size());
        for (const auto &pair : std::as_const(estimatedPairs)) {
            const QString key = normalizedPairKey(pair.first, pair.second);
            if (exceptionKeys.contains(key))
                continue;
            filteredEstimatedPairs.append(pair);
        }
        estimatedPairs = filteredEstimatedPairs;
        const QSet<QString> estimatedKeys = pairKeys(estimatedPairs);

        QStringList parseWarnings;
        QVector<RealDivisionEntry> realEntries = readDivisionPairs(realDivisionFile, parseWarnings);
        QVector<QPair<int, int>> realPairs;
        realPairs.reserve(realEntries.size());
        QHash<QString, int> realPairTimes;
        for (const RealDivisionEntry &entry : std::as_const(realEntries)) {
            const QString key = normalizedPairKey(entry.firstId, entry.secondId);
            if (exceptionKeys.contains(key))
                continue;
            realPairs.append(QPair<int, int>(entry.firstId, entry.secondId));
            realPairTimes.insert(key, entry.time);
        }

        if (realPairs.isEmpty()) {
            summary.warnings << QString("%1: no valid real division pairs found in %2")
                                .arg(info.fileName())
                                .arg(QFileInfo(realDivisionFile).fileName());
        }
        const QSet<QString> realKeys = pairKeys(realPairs);

        for (const auto &neighbor : neighbors) {
            const QString neighborKey = normalizedPairKey(neighbor.first, neighbor.second);
            if (exceptionKeys.contains(neighborKey))
                continue;

            PolygonItem *firstPoly = polygonsById.value(neighbor.first, nullptr);
            PolygonItem *secondPoly = polygonsById.value(neighbor.second, nullptr);
            if (!firstPoly || !secondPoly) {
                summary.warnings << QString("%1: neighbor pair (%2, %3) references missing polygons.")
                                    .arg(info.fileName())
                                    .arg(neighbor.first)
                                    .arg(neighbor.second);
                continue;
            }

            NeighborPairGeometryCalculator::Result geometry = NeighborPairGeometryCalculator::calculateForPair(firstPoly, secondPoly, geometrySettings);
            geometry.first = nullptr;
            geometry.second = nullptr;

            DivisionPairRow pairRow;
            pairRow.fileName = info.fileName();
            pairRow.firstId = neighbor.first;
            pairRow.secondId = neighbor.second;
            pairRow.geometry = geometry;
            pairRow.observedDivision = realKeys.contains(neighborKey);
            pairRow.estimatedDivision = estimatedKeys.contains(neighborKey);
            pairRow.divisionTime = realPairTimes.value(neighborKey, -1);
            summary.pairRows.append(pairRow);
        }

        FileDivisionResult fileResult;
        fileResult.fileName = info.fileName();
        fileResult.neighborPairCount = neighbors.size();
        fileResult.estimatedPairs = estimatedPairs;
        fileResult.realPairs = realPairs;
        fileResult.metrics = calculateMetrics(neighbors, estimatedPairs, realPairs);

        summary.files.append(fileResult);
        ++summary.filesWithResults;

        totalNeighborPairs += fileResult.metrics.neighborPairs;
        totalTruePositives += fileResult.metrics.truePositives;
        totalFalsePositives += fileResult.metrics.falsePositives;
        totalFalseNegatives += fileResult.metrics.falseNegatives;
        totalEstimatedPairs += std::max(0, fileResult.metrics.estimatedPairs);
        totalRealPairs += std::max(0, fileResult.metrics.realPairs);

        for (const QString &warn : parseWarnings)
            summary.warnings << QString("%1: %2").arg(info.fileName(), warn);
    }

    summary.totals = metricsFromCounts(totalNeighborPairs,
                                       totalTruePositives,
                                       totalFalsePositives,
                                       totalFalseNegatives,
                                       totalEstimatedPairs,
                                       totalRealPairs);

    return summary;
}

BatchDivisionEstimator::BatchResult BatchDivisionEstimator::estimateGeometryCsv(
        const QString &filePath, const DivisionEstimator::Criterion &criterion)
{
    BatchResult summary;
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        summary.errors << QString("Unable to open %1: %2").arg(filePath, file.errorString());
        return summary;
    }

    QTextStream stream(&file);
    if (stream.atEnd()) {
        summary.errors << QString("Geometry CSV is empty: %1").arg(filePath);
        return summary;
    }

    const QStringList headers = parseCsvLine(stream.readLine());
    QHash<QString, int> columns;
    for (int i = 0; i < headers.size(); ++i)
        columns.insert(headers.at(i).trimmed().toLower(), i);
    const auto column = [&columns](const QString &name) { return columns.value(name.toLower(), -1); };
    const int fileColumn = column("fileName");
    const int firstColumn = column("firstPolygonId");
    const int secondColumn = column("secondPolygonId");
    const int observedColumn = column("observed_division");
    const int exceptionColumn = column("exception_label");
    const int timingColumn = column("division_timing");
    const int featureColumn = column(criterion.featureKey);
    if (fileColumn < 0 || firstColumn < 0 || secondColumn < 0 || observedColumn < 0
            || exceptionColumn < 0 || featureColumn < 0) {
        summary.errors << QString("CSV must contain fileName, firstPolygonId, secondPolygonId, "
                                  "observed_division, exception_label, and the selected feature column '%1'.")
                              .arg(criterion.featureKey);
        return summary;
    }

    struct CsvPair { DivisionPairRow row; double value = 0.0; double score = 0.0; };
    QHash<QString, QVector<CsvPair>> rowsByFile;
    int lineNumber = 1;
    while (!stream.atEnd()) {
        ++lineNumber;
        const QString line = stream.readLine();
        if (line.trimmed().isEmpty())
            continue;
        const QStringList fields = parseCsvLine(line);
        const auto field = [&fields](int index) { return index >= 0 && index < fields.size() ? fields.at(index).trimmed() : QString(); };
        bool firstOk = false, secondOk = false, valueOk = false;
        const int first = field(firstColumn).toInt(&firstOk);
        const int second = field(secondColumn).toInt(&secondOk);
        const double value = field(featureColumn).toDouble(&valueOk);
        if (!firstOk || !secondOk || !valueOk || !std::isfinite(value)) {
            summary.warnings << QString("Line %1: invalid cell IDs or selected feature value; row ignored.").arg(lineNumber);
            continue;
        }
        const QString fileName = field(fileColumn);
        if (fileName.isEmpty()) {
            summary.warnings << QString("Line %1: empty fileName; row ignored.").arg(lineNumber);
            continue;
        }
        // Exception-labelled pairs are excluded before matching as well as from every metric.
        if (field(exceptionColumn).toInt() != 0)
            continue;

        CsvPair pair;
        pair.row.fileName = fileName;
        pair.row.firstId = first;
        pair.row.secondId = second;
        pair.row.observedDivision = field(observedColumn).toInt() != 0;
        pair.row.divisionTime = timingColumn >= 0 ? field(timingColumn).toInt() : -1;
        pair.row.geometry = geometryFromCsv(fields, columns);
        pair.value = value;
        pair.score = criterion.requireAbove ? value - criterion.threshold : criterion.threshold - value;
        rowsByFile[fileName].append(pair);
    }

    for (auto fileIt = rowsByFile.begin(); fileIt != rowsByFile.end(); ++fileIt) {
        QVector<CsvPair> &pairs = fileIt.value();
        ++summary.filesProcessed;
        if (pairs.isEmpty())
            continue;

        QSet<int> idSet;
        for (const CsvPair &pair : std::as_const(pairs)) { idSet.insert(pair.row.firstId); idSet.insert(pair.row.secondId); }
        QList<int> ids = idSet.values();
        std::sort(ids.begin(), ids.end());
        QHash<int, int> indexById;
        for (int i = 0; i < ids.size(); ++i) indexById.insert(ids.at(i), i);

        QVector<int> candidates;
        for (int i = 0; i < pairs.size(); ++i) {
            if ((criterion.requireAbove && pairs[i].value >= criterion.threshold)
                    || (!criterion.requireAbove && pairs[i].value <= criterion.threshold))
                candidates.append(i);
        }
        QSet<int> selected;
        if (criterion.matchingMode == DivisionEstimator::Criterion::MatchingMode::Unconstrained) {
            for (int i : std::as_const(candidates)) selected.insert(i);
        } else if (criterion.matchingMode == DivisionEstimator::Criterion::MatchingMode::GlobalMaximumWeight) {
            QVector<WeightedMatching::Edge> edges;
            for (int i : std::as_const(candidates))
                edges.append({indexById.value(pairs[i].row.firstId), indexById.value(pairs[i].row.secondId), pairs[i].score, i});
            for (const auto &edge : WeightedMatching::solve(ids.size(), edges)) selected.insert(edge.sourceIndex);
        } else {
            std::sort(candidates.begin(), candidates.end(), [&pairs](int a, int b) { return pairs[a].score > pairs[b].score; });
            QSet<int> used;
            for (int i : std::as_const(candidates)) {
                if (used.contains(pairs[i].row.firstId) || used.contains(pairs[i].row.secondId)) continue;
                selected.insert(i); used.insert(pairs[i].row.firstId); used.insert(pairs[i].row.secondId);
            }
        }

        QVector<QPair<int, int>> neighbors, estimated, real;
        for (int i = 0; i < pairs.size(); ++i) {
            CsvPair &pair = pairs[i];
            pair.row.estimatedDivision = selected.contains(i);
            neighbors.append({pair.row.firstId, pair.row.secondId});
            if (pair.row.estimatedDivision) estimated.append(neighbors.last());
            if (pair.row.observedDivision) real.append(neighbors.last());
            summary.pairRows.append(pair.row);
        }
        FileDivisionResult result;
        result.fileName = fileIt.key(); result.neighborPairCount = neighbors.size();
        result.estimatedPairs = estimated; result.realPairs = real;
        result.metrics = calculateMetrics(neighbors, estimated, real);
        summary.files.append(result); ++summary.filesWithResults;
    }

    int neighbors = 0, tp = 0, fp = 0, fn = 0, estimated = 0, real = 0;
    for (const FileDivisionResult &result : std::as_const(summary.files)) {
        neighbors += result.metrics.neighborPairs; tp += result.metrics.truePositives;
        fp += result.metrics.falsePositives; fn += result.metrics.falseNegatives;
        estimated += result.metrics.estimatedPairs; real += result.metrics.realPairs;
    }
    summary.totals = metricsFromCounts(neighbors, tp, fp, fn, estimated, real);
    return summary;
}

QVector<BatchDivisionEstimator::DesignatedGeometryConfig> BatchDivisionEstimator::loadDesignatedGeometryConfigCsv(const QString &filePath,
                                                                                                                  QStringList *warnings,
                                                                                                                  QStringList *errors)
{
    QVector<DesignatedGeometryConfig> configs;
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        if (errors)
            errors->append(QString("Unable to open %1: %2").arg(filePath, file.errorString()));
        return configs;
    }

    QTextStream in(&file);
    if (in.atEnd()) {
        if (warnings)
            warnings->append(QString("%1 is empty.").arg(QFileInfo(filePath).fileName()));
        return configs;
    }

    const QString headerLine = in.readLine();
    const QStringList headers = parseCsvLine(headerLine);
    QHash<QString, int> columnIndex;
    for (int i = 0; i < headers.size(); ++i) {
        columnIndex.insert(normalizeFeatureName(headers.at(i)), i);
    }

    const auto column = [&columnIndex](const QString &name) {
        return columnIndex.value(normalizeFeatureName(name), -1);
    };

    const int featureIdx = column("feature");
    const int cutoffIdx = column("cutoff_value");
    const int directionIdx = column("below_or_above");
    const int noteIdx = column("note");
    const int detailDirectionIdx = column("direction");

    int lineNumber = 1;
    while (!in.atEnd()) {
        const QString rawLine = in.readLine();
        ++lineNumber;
        if (rawLine.trimmed().isEmpty())
            continue;

        const QStringList fields = parseCsvLine(rawLine);
        if (fields.isEmpty())
            continue;

        auto fieldValue = [&fields](int idx) -> QString {
            if (idx < 0 || idx >= fields.size())
                return {};
            return fields.at(idx).trimmed();
        };

        DesignatedGeometryConfig config;
        config.featureName = fieldValue(featureIdx >= 0 ? featureIdx : 0);
        config.direction = fieldValue(detailDirectionIdx);
        config.note = fieldValue(noteIdx);

        const QString cutoffStr = fieldValue(cutoffIdx >= 0 ? cutoffIdx : -1);
        bool okCutoff = false;
        config.cutoffValue = cutoffStr.toDouble(&okCutoff);
        if (!okCutoff) {
            if (errors)
                errors->append(QString("Line %1: invalid cutoff value '%2'.").arg(lineNumber).arg(cutoffStr));
            continue;
        }

        const QString dirValue = fieldValue(directionIdx);
        if (!dirValue.isEmpty()) {
            const QString normalizedDir = dirValue.trimmed().toLower();
            if (normalizedDir.contains("below"))
                config.requireAbove = false;
            else if (normalizedDir.contains("above"))
                config.requireAbove = true;
            else if (warnings)
                warnings->append(QString("Line %1: unrecognized below_or_above value '%2', defaulting to above.").arg(lineNumber).arg(dirValue));
        }

        if (config.featureName.isEmpty()) {
            if (errors)
                errors->append(QString("Line %1: missing feature name.").arg(lineNumber));
            continue;
        }

        configs.append(config);
    }

    if (configs.isEmpty() && errors && errors->isEmpty() && warnings)
        warnings->append(QString("No valid configurations found in %1.").arg(QFileInfo(filePath).fileName()));

    return configs;
}

QVector<BatchDivisionEstimator::DesignatedGeometryResult> BatchDivisionEstimator::estimateDesignatedGeometry(
        const QString &directoryPath,
        const QVector<DesignatedGeometryConfig> &configs)
{
    QVector<DesignatedGeometryResult> results;
    results.reserve(configs.size());

    const QVector<DivisionEstimator::FeatureOption> options = DivisionEstimator::featureOptions();

    for (const DesignatedGeometryConfig &config : configs) {
        DesignatedGeometryResult result;
        result.config = config;

        const QString key = featureKeyFromName(config.featureName);
        if (key.isEmpty()) {
            result.errors << QString("Unknown feature '%1'.").arg(config.featureName);
            results.append(result);
            continue;
        }

        DivisionEstimator::FeatureOption option;
        for (const auto &opt : options) {
            if (opt.key == key) {
                option = opt;
                break;
            }
        }

        if (option.key.isEmpty()) {
            result.errors << QString("Feature '%1' is not available for estimation.").arg(config.featureName);
            results.append(result);
            continue;
        }

        DivisionEstimator::Criterion criterion;
        if (!DivisionEstimator::populateCriterionFromSelection(option, config.requireAbove, config.cutoffValue, criterion)) {
            result.errors << QString("Failed to configure criterion for feature '%1'.").arg(config.featureName);
            results.append(result);
            continue;
        }

        result.featureKey = option.key;
        result.featureLabel = option.label;

        const BatchResult batch = estimateDirectory(directoryPath, criterion);
        result.metrics = batch.totals;
        result.filesProcessed = batch.filesProcessed;
        result.filesWithResults = batch.filesWithResults;
        result.warnings = batch.warnings;
        result.errors.append(batch.errors);

        results.append(result);
    }

    return results;
}

bool BatchDivisionEstimator::exportDesignatedGeometryMetricsToCsv(const QString &filePath,
                                                                  const QVector<DesignatedGeometryResult> &results,
                                                                  QString *errorMessage)
{
    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        if (errorMessage)
            *errorMessage = QString("Unable to open %1 for writing").arg(filePath);
        return false;
    }

    QTextStream stream(&file);
    QStringList headers = {
        "feature",
        "feature_key",
        "threshold",
        "comparison",
        "files_processed",
        "files_with_results",
        "estimated_pairs",
        "real_pairs",
        "true_positive",
        "false_positive",
        "false_negative",
        "true_negative",
        "precision",
        "recall",
        "f1",
        "specificity",
        "accuracy",
        "direction",
        "note",
        "warnings",
        "errors"
    };
    for (QString &header : headers)
        header = escapeForCsv(header);
    stream << headers.join(',') << '\n';

    for (const DesignatedGeometryResult &res : results) {
        QStringList row;
        row << res.featureLabel;
        row << res.featureKey;
        row << QString::number(res.config.cutoffValue, 'f', 6);
        row << (res.config.requireAbove ? ">= cutoff" : "<= cutoff");
        row << QString::number(res.filesProcessed);
        row << QString::number(res.filesWithResults);
        row << QString::number(std::max(0, res.metrics.estimatedPairs));
        row << QString::number(std::max(0, res.metrics.realPairs));
        row << QString::number(res.metrics.truePositives);
        row << QString::number(res.metrics.falsePositives);
        row << QString::number(res.metrics.falseNegatives);
        row << QString::number(res.metrics.trueNegatives);
        row << formatValue(res.metrics.precision);
        row << formatValue(res.metrics.recall);
        row << formatValue(res.metrics.f1);
        row << formatValue(res.metrics.specificity);
        row << formatValue(res.metrics.accuracy);
        row << res.config.direction;
        row << res.config.note;
        row << res.warnings.join(" | ");
        row << res.errors.join(" | ");

        for (QString &field : row)
            field = escapeForCsv(field);
        stream << row.join(',') << '\n';
    }

    return true;
}
